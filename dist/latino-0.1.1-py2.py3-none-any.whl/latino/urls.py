TRANSLATE = {
    "it": "https://www.dizionario-latino.com/dizionario-latino-italiano.php",
    "en": "https://www.online-latin-dictionary.com/latin-english-dictionary.php",
    "fr": "https://www.grand-dictionnaire-latin.com/dictionnaire-latin-francais.php"
}

BASE = {
    "it": "https://www.dizionario-latino.com/",
    "en": "https://www.online-latin-dictionary.com/",
    "fr": "https://www.grand-dictionnaire-latin.com/"
}
