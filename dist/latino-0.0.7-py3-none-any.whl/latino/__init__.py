from latino.latino import lat_eng, lat_fra, lat_ita

__all__ = ['lat_eng', 'lat_fra', 'lat_ita']
