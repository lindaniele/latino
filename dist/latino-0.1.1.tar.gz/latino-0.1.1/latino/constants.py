LANGUAGES = {
    "it": "italiano",
    "en": "english",
    "fr": "francais"
}
